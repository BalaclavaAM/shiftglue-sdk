#include "ffx_fsr2_lock_pass_4e7ed4bba3bdf50e7dc444af60a84b11.h"
#include "ffx_fsr2_lock_pass_3ab7b37a78d3eca0427561c0129d5e14.h"

typedef union ffx_fsr2_lock_pass_PermutationKey {
    struct {
        uint32_t FFX_FSR2_OPTION_JITTERED_MOTION_VECTORS : 1;
        uint32_t FFX_FSR2_OPTION_INVERTED_DEPTH : 1;
        uint32_t FFX_FSR2_OPTION_REPROJECT_USE_LANCZOS_TYPE : 1;
        uint32_t FFX_FSR2_OPTION_HDR_COLOR_INPUT : 1;
        uint32_t FFX_FSR2_OPTION_LOW_RESOLUTION_MOTION_VECTORS : 1;
        uint32_t FFX_FSR2_OPTION_APPLY_SHARPENING : 1;
    };
    uint32_t index;
} ffx_fsr2_lock_pass_PermutationKey;

typedef struct ffx_fsr2_lock_pass_PermutationInfo {
    const uint32_t       blobSize;
    const unsigned char* blobData;


    const uint32_t  numConstantBuffers;
    const char**    constantBufferNames;
    const uint32_t* constantBufferBindings;
    const uint32_t* constantBufferCounts;
    const uint32_t* constantBufferSpaces;

    const uint32_t  numSRVTextures;
    const char**    srvTextureNames;
    const uint32_t* srvTextureBindings;
    const uint32_t* srvTextureCounts;
    const uint32_t* srvTextureSpaces;

    const uint32_t  numUAVTextures;
    const char**    uavTextureNames;
    const uint32_t* uavTextureBindings;
    const uint32_t* uavTextureCounts;
    const uint32_t* uavTextureSpaces;

    const uint32_t  numSRVBuffers;
    const char**    srvBufferNames;
    const uint32_t* srvBufferBindings;
    const uint32_t* srvBufferCounts;
    const uint32_t* srvBufferSpaces;

    const uint32_t  numUAVBuffers;
    const char**    uavBufferNames;
    const uint32_t* uavBufferBindings;
    const uint32_t* uavBufferCounts;
    const uint32_t* uavBufferSpaces;

    const uint32_t  numSamplers;
    const char**    samplerNames;
    const uint32_t* samplerBindings;
    const uint32_t* samplerCounts;
    const uint32_t* samplerSpaces;

    const uint32_t  numRTAccelerationStructures;
    const char**    rtAccelerationStructureNames;
    const uint32_t* rtAccelerationStructureBindings;
    const uint32_t* rtAccelerationStructureCounts;
    const uint32_t* rtAccelerationStructureSpaces;
} ffx_fsr2_lock_pass_PermutationInfo;

static const uint32_t g_ffx_fsr2_lock_pass_IndirectionTable[] = {
    0,
    0,
    1,
    1,
    0,
    0,
    1,
    1,
    0,
    0,
    1,
    1,
    0,
    0,
    1,
    1,
    0,
    0,
    1,
    1,
    0,
    0,
    1,
    1,
    0,
    0,
    1,
    1,
    0,
    0,
    1,
    1,
    0,
    0,
    1,
    1,
    0,
    0,
    1,
    1,
    0,
    0,
    1,
    1,
    0,
    0,
    1,
    1,
    0,
    0,
    1,
    1,
    0,
    0,
    1,
    1,
    0,
    0,
    1,
    1,
    0,
    0,
    1,
    1,
};

static const ffx_fsr2_lock_pass_PermutationInfo g_ffx_fsr2_lock_pass_PermutationInfo[] = {
    { g_ffx_fsr2_lock_pass_4e7ed4bba3bdf50e7dc444af60a84b11_size, g_ffx_fsr2_lock_pass_4e7ed4bba3bdf50e7dc444af60a84b11_data, 1, g_ffx_fsr2_lock_pass_4e7ed4bba3bdf50e7dc444af60a84b11_CBVResourceNames, g_ffx_fsr2_lock_pass_4e7ed4bba3bdf50e7dc444af60a84b11_CBVResourceBindings, g_ffx_fsr2_lock_pass_4e7ed4bba3bdf50e7dc444af60a84b11_CBVResourceCounts, g_ffx_fsr2_lock_pass_4e7ed4bba3bdf50e7dc444af60a84b11_CBVResourceSets, 1, g_ffx_fsr2_lock_pass_4e7ed4bba3bdf50e7dc444af60a84b11_TextureSRVResourceNames, g_ffx_fsr2_lock_pass_4e7ed4bba3bdf50e7dc444af60a84b11_TextureSRVResourceBindings, g_ffx_fsr2_lock_pass_4e7ed4bba3bdf50e7dc444af60a84b11_TextureSRVResourceCounts, g_ffx_fsr2_lock_pass_4e7ed4bba3bdf50e7dc444af60a84b11_TextureSRVResourceSets, 2, g_ffx_fsr2_lock_pass_4e7ed4bba3bdf50e7dc444af60a84b11_TextureUAVResourceNames, g_ffx_fsr2_lock_pass_4e7ed4bba3bdf50e7dc444af60a84b11_TextureUAVResourceBindings, g_ffx_fsr2_lock_pass_4e7ed4bba3bdf50e7dc444af60a84b11_TextureUAVResourceCounts, g_ffx_fsr2_lock_pass_4e7ed4bba3bdf50e7dc444af60a84b11_TextureUAVResourceSets, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, },
    { g_ffx_fsr2_lock_pass_3ab7b37a78d3eca0427561c0129d5e14_size, g_ffx_fsr2_lock_pass_3ab7b37a78d3eca0427561c0129d5e14_data, 1, g_ffx_fsr2_lock_pass_3ab7b37a78d3eca0427561c0129d5e14_CBVResourceNames, g_ffx_fsr2_lock_pass_3ab7b37a78d3eca0427561c0129d5e14_CBVResourceBindings, g_ffx_fsr2_lock_pass_3ab7b37a78d3eca0427561c0129d5e14_CBVResourceCounts, g_ffx_fsr2_lock_pass_3ab7b37a78d3eca0427561c0129d5e14_CBVResourceSets, 1, g_ffx_fsr2_lock_pass_3ab7b37a78d3eca0427561c0129d5e14_TextureSRVResourceNames, g_ffx_fsr2_lock_pass_3ab7b37a78d3eca0427561c0129d5e14_TextureSRVResourceBindings, g_ffx_fsr2_lock_pass_3ab7b37a78d3eca0427561c0129d5e14_TextureSRVResourceCounts, g_ffx_fsr2_lock_pass_3ab7b37a78d3eca0427561c0129d5e14_TextureSRVResourceSets, 2, g_ffx_fsr2_lock_pass_3ab7b37a78d3eca0427561c0129d5e14_TextureUAVResourceNames, g_ffx_fsr2_lock_pass_3ab7b37a78d3eca0427561c0129d5e14_TextureUAVResourceBindings, g_ffx_fsr2_lock_pass_3ab7b37a78d3eca0427561c0129d5e14_TextureUAVResourceCounts, g_ffx_fsr2_lock_pass_3ab7b37a78d3eca0427561c0129d5e14_TextureUAVResourceSets, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, },
};


#include "ffx_fsr2_depth_clip_pass_740a10678efcae16da044848945f1050.h"
#include "ffx_fsr2_depth_clip_pass_1b04413d452e0cc4fbccd69e361c7999.h"
#include "ffx_fsr2_depth_clip_pass_ffa17fbe022fadcc0c2c4939e1af8c8d.h"
#include "ffx_fsr2_depth_clip_pass_7788e61b08250444fe538f6927b876cf.h"
#include "ffx_fsr2_depth_clip_pass_5ac420717bf1b90c9d119e6b959d751a.h"
#include "ffx_fsr2_depth_clip_pass_adaf8f0e7b2d6456053eac86ff26e3f8.h"
#include "ffx_fsr2_depth_clip_pass_b6baac80d7cd8ba5f1a20e78bd2e7e3b.h"
#include "ffx_fsr2_depth_clip_pass_c4b4a1b9ebe6e75fc4a5817dad83144a.h"

typedef union ffx_fsr2_depth_clip_pass_PermutationKey {
    struct {
        uint32_t FFX_FSR2_OPTION_LOW_RESOLUTION_MOTION_VECTORS : 1;
        uint32_t FFX_FSR2_OPTION_JITTERED_MOTION_VECTORS : 1;
        uint32_t FFX_FSR2_OPTION_INVERTED_DEPTH : 1;
        uint32_t FFX_FSR2_OPTION_REPROJECT_USE_LANCZOS_TYPE : 1;
        uint32_t FFX_FSR2_OPTION_HDR_COLOR_INPUT : 1;
        uint32_t FFX_FSR2_OPTION_APPLY_SHARPENING : 1;
    };
    uint32_t index;
} ffx_fsr2_depth_clip_pass_PermutationKey;

typedef struct ffx_fsr2_depth_clip_pass_PermutationInfo {
    const uint32_t       blobSize;
    const unsigned char* blobData;


    const uint32_t  numConstantBuffers;
    const char**    constantBufferNames;
    const uint32_t* constantBufferBindings;
    const uint32_t* constantBufferCounts;
    const uint32_t* constantBufferSpaces;

    const uint32_t  numSRVTextures;
    const char**    srvTextureNames;
    const uint32_t* srvTextureBindings;
    const uint32_t* srvTextureCounts;
    const uint32_t* srvTextureSpaces;

    const uint32_t  numUAVTextures;
    const char**    uavTextureNames;
    const uint32_t* uavTextureBindings;
    const uint32_t* uavTextureCounts;
    const uint32_t* uavTextureSpaces;

    const uint32_t  numSRVBuffers;
    const char**    srvBufferNames;
    const uint32_t* srvBufferBindings;
    const uint32_t* srvBufferCounts;
    const uint32_t* srvBufferSpaces;

    const uint32_t  numUAVBuffers;
    const char**    uavBufferNames;
    const uint32_t* uavBufferBindings;
    const uint32_t* uavBufferCounts;
    const uint32_t* uavBufferSpaces;

    const uint32_t  numSamplers;
    const char**    samplerNames;
    const uint32_t* samplerBindings;
    const uint32_t* samplerCounts;
    const uint32_t* samplerSpaces;

    const uint32_t  numRTAccelerationStructures;
    const char**    rtAccelerationStructureNames;
    const uint32_t* rtAccelerationStructureBindings;
    const uint32_t* rtAccelerationStructureCounts;
    const uint32_t* rtAccelerationStructureSpaces;
} ffx_fsr2_depth_clip_pass_PermutationInfo;

static const uint32_t g_ffx_fsr2_depth_clip_pass_IndirectionTable[] = {
    7,
    4,
    6,
    0,
    3,
    1,
    5,
    2,
    7,
    4,
    6,
    0,
    3,
    1,
    5,
    2,
    7,
    4,
    6,
    0,
    3,
    1,
    5,
    2,
    7,
    4,
    6,
    0,
    3,
    1,
    5,
    2,
    7,
    4,
    6,
    0,
    3,
    1,
    5,
    2,
    7,
    4,
    6,
    0,
    3,
    1,
    5,
    2,
    7,
    4,
    6,
    0,
    3,
    1,
    5,
    2,
    7,
    4,
    6,
    0,
    3,
    1,
    5,
    2,
};

static const ffx_fsr2_depth_clip_pass_PermutationInfo g_ffx_fsr2_depth_clip_pass_PermutationInfo[] = {
    { g_ffx_fsr2_depth_clip_pass_740a10678efcae16da044848945f1050_size, g_ffx_fsr2_depth_clip_pass_740a10678efcae16da044848945f1050_data, 1, g_ffx_fsr2_depth_clip_pass_740a10678efcae16da044848945f1050_CBVResourceNames, g_ffx_fsr2_depth_clip_pass_740a10678efcae16da044848945f1050_CBVResourceBindings, g_ffx_fsr2_depth_clip_pass_740a10678efcae16da044848945f1050_CBVResourceCounts, g_ffx_fsr2_depth_clip_pass_740a10678efcae16da044848945f1050_CBVResourceSets, 9, g_ffx_fsr2_depth_clip_pass_740a10678efcae16da044848945f1050_TextureSRVResourceNames, g_ffx_fsr2_depth_clip_pass_740a10678efcae16da044848945f1050_TextureSRVResourceBindings, g_ffx_fsr2_depth_clip_pass_740a10678efcae16da044848945f1050_TextureSRVResourceCounts, g_ffx_fsr2_depth_clip_pass_740a10678efcae16da044848945f1050_TextureSRVResourceSets, 2, g_ffx_fsr2_depth_clip_pass_740a10678efcae16da044848945f1050_TextureUAVResourceNames, g_ffx_fsr2_depth_clip_pass_740a10678efcae16da044848945f1050_TextureUAVResourceBindings, g_ffx_fsr2_depth_clip_pass_740a10678efcae16da044848945f1050_TextureUAVResourceCounts, g_ffx_fsr2_depth_clip_pass_740a10678efcae16da044848945f1050_TextureUAVResourceSets, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, g_ffx_fsr2_depth_clip_pass_740a10678efcae16da044848945f1050_SamplerResourceNames, g_ffx_fsr2_depth_clip_pass_740a10678efcae16da044848945f1050_SamplerResourceBindings, g_ffx_fsr2_depth_clip_pass_740a10678efcae16da044848945f1050_SamplerResourceCounts, g_ffx_fsr2_depth_clip_pass_740a10678efcae16da044848945f1050_SamplerResourceSets, 0, 0, 0, 0, 0, },
    { g_ffx_fsr2_depth_clip_pass_1b04413d452e0cc4fbccd69e361c7999_size, g_ffx_fsr2_depth_clip_pass_1b04413d452e0cc4fbccd69e361c7999_data, 1, g_ffx_fsr2_depth_clip_pass_1b04413d452e0cc4fbccd69e361c7999_CBVResourceNames, g_ffx_fsr2_depth_clip_pass_1b04413d452e0cc4fbccd69e361c7999_CBVResourceBindings, g_ffx_fsr2_depth_clip_pass_1b04413d452e0cc4fbccd69e361c7999_CBVResourceCounts, g_ffx_fsr2_depth_clip_pass_1b04413d452e0cc4fbccd69e361c7999_CBVResourceSets, 9, g_ffx_fsr2_depth_clip_pass_1b04413d452e0cc4fbccd69e361c7999_TextureSRVResourceNames, g_ffx_fsr2_depth_clip_pass_1b04413d452e0cc4fbccd69e361c7999_TextureSRVResourceBindings, g_ffx_fsr2_depth_clip_pass_1b04413d452e0cc4fbccd69e361c7999_TextureSRVResourceCounts, g_ffx_fsr2_depth_clip_pass_1b04413d452e0cc4fbccd69e361c7999_TextureSRVResourceSets, 2, g_ffx_fsr2_depth_clip_pass_1b04413d452e0cc4fbccd69e361c7999_TextureUAVResourceNames, g_ffx_fsr2_depth_clip_pass_1b04413d452e0cc4fbccd69e361c7999_TextureUAVResourceBindings, g_ffx_fsr2_depth_clip_pass_1b04413d452e0cc4fbccd69e361c7999_TextureUAVResourceCounts, g_ffx_fsr2_depth_clip_pass_1b04413d452e0cc4fbccd69e361c7999_TextureUAVResourceSets, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, g_ffx_fsr2_depth_clip_pass_1b04413d452e0cc4fbccd69e361c7999_SamplerResourceNames, g_ffx_fsr2_depth_clip_pass_1b04413d452e0cc4fbccd69e361c7999_SamplerResourceBindings, g_ffx_fsr2_depth_clip_pass_1b04413d452e0cc4fbccd69e361c7999_SamplerResourceCounts, g_ffx_fsr2_depth_clip_pass_1b04413d452e0cc4fbccd69e361c7999_SamplerResourceSets, 0, 0, 0, 0, 0, },
    { g_ffx_fsr2_depth_clip_pass_ffa17fbe022fadcc0c2c4939e1af8c8d_size, g_ffx_fsr2_depth_clip_pass_ffa17fbe022fadcc0c2c4939e1af8c8d_data, 1, g_ffx_fsr2_depth_clip_pass_ffa17fbe022fadcc0c2c4939e1af8c8d_CBVResourceNames, g_ffx_fsr2_depth_clip_pass_ffa17fbe022fadcc0c2c4939e1af8c8d_CBVResourceBindings, g_ffx_fsr2_depth_clip_pass_ffa17fbe022fadcc0c2c4939e1af8c8d_CBVResourceCounts, g_ffx_fsr2_depth_clip_pass_ffa17fbe022fadcc0c2c4939e1af8c8d_CBVResourceSets, 9, g_ffx_fsr2_depth_clip_pass_ffa17fbe022fadcc0c2c4939e1af8c8d_TextureSRVResourceNames, g_ffx_fsr2_depth_clip_pass_ffa17fbe022fadcc0c2c4939e1af8c8d_TextureSRVResourceBindings, g_ffx_fsr2_depth_clip_pass_ffa17fbe022fadcc0c2c4939e1af8c8d_TextureSRVResourceCounts, g_ffx_fsr2_depth_clip_pass_ffa17fbe022fadcc0c2c4939e1af8c8d_TextureSRVResourceSets, 2, g_ffx_fsr2_depth_clip_pass_ffa17fbe022fadcc0c2c4939e1af8c8d_TextureUAVResourceNames, g_ffx_fsr2_depth_clip_pass_ffa17fbe022fadcc0c2c4939e1af8c8d_TextureUAVResourceBindings, g_ffx_fsr2_depth_clip_pass_ffa17fbe022fadcc0c2c4939e1af8c8d_TextureUAVResourceCounts, g_ffx_fsr2_depth_clip_pass_ffa17fbe022fadcc0c2c4939e1af8c8d_TextureUAVResourceSets, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, g_ffx_fsr2_depth_clip_pass_ffa17fbe022fadcc0c2c4939e1af8c8d_SamplerResourceNames, g_ffx_fsr2_depth_clip_pass_ffa17fbe022fadcc0c2c4939e1af8c8d_SamplerResourceBindings, g_ffx_fsr2_depth_clip_pass_ffa17fbe022fadcc0c2c4939e1af8c8d_SamplerResourceCounts, g_ffx_fsr2_depth_clip_pass_ffa17fbe022fadcc0c2c4939e1af8c8d_SamplerResourceSets, 0, 0, 0, 0, 0, },
    { g_ffx_fsr2_depth_clip_pass_7788e61b08250444fe538f6927b876cf_size, g_ffx_fsr2_depth_clip_pass_7788e61b08250444fe538f6927b876cf_data, 1, g_ffx_fsr2_depth_clip_pass_7788e61b08250444fe538f6927b876cf_CBVResourceNames, g_ffx_fsr2_depth_clip_pass_7788e61b08250444fe538f6927b876cf_CBVResourceBindings, g_ffx_fsr2_depth_clip_pass_7788e61b08250444fe538f6927b876cf_CBVResourceCounts, g_ffx_fsr2_depth_clip_pass_7788e61b08250444fe538f6927b876cf_CBVResourceSets, 9, g_ffx_fsr2_depth_clip_pass_7788e61b08250444fe538f6927b876cf_TextureSRVResourceNames, g_ffx_fsr2_depth_clip_pass_7788e61b08250444fe538f6927b876cf_TextureSRVResourceBindings, g_ffx_fsr2_depth_clip_pass_7788e61b08250444fe538f6927b876cf_TextureSRVResourceCounts, g_ffx_fsr2_depth_clip_pass_7788e61b08250444fe538f6927b876cf_TextureSRVResourceSets, 2, g_ffx_fsr2_depth_clip_pass_7788e61b08250444fe538f6927b876cf_TextureUAVResourceNames, g_ffx_fsr2_depth_clip_pass_7788e61b08250444fe538f6927b876cf_TextureUAVResourceBindings, g_ffx_fsr2_depth_clip_pass_7788e61b08250444fe538f6927b876cf_TextureUAVResourceCounts, g_ffx_fsr2_depth_clip_pass_7788e61b08250444fe538f6927b876cf_TextureUAVResourceSets, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, g_ffx_fsr2_depth_clip_pass_7788e61b08250444fe538f6927b876cf_SamplerResourceNames, g_ffx_fsr2_depth_clip_pass_7788e61b08250444fe538f6927b876cf_SamplerResourceBindings, g_ffx_fsr2_depth_clip_pass_7788e61b08250444fe538f6927b876cf_SamplerResourceCounts, g_ffx_fsr2_depth_clip_pass_7788e61b08250444fe538f6927b876cf_SamplerResourceSets, 0, 0, 0, 0, 0, },
    { g_ffx_fsr2_depth_clip_pass_5ac420717bf1b90c9d119e6b959d751a_size, g_ffx_fsr2_depth_clip_pass_5ac420717bf1b90c9d119e6b959d751a_data, 1, g_ffx_fsr2_depth_clip_pass_5ac420717bf1b90c9d119e6b959d751a_CBVResourceNames, g_ffx_fsr2_depth_clip_pass_5ac420717bf1b90c9d119e6b959d751a_CBVResourceBindings, g_ffx_fsr2_depth_clip_pass_5ac420717bf1b90c9d119e6b959d751a_CBVResourceCounts, g_ffx_fsr2_depth_clip_pass_5ac420717bf1b90c9d119e6b959d751a_CBVResourceSets, 9, g_ffx_fsr2_depth_clip_pass_5ac420717bf1b90c9d119e6b959d751a_TextureSRVResourceNames, g_ffx_fsr2_depth_clip_pass_5ac420717bf1b90c9d119e6b959d751a_TextureSRVResourceBindings, g_ffx_fsr2_depth_clip_pass_5ac420717bf1b90c9d119e6b959d751a_TextureSRVResourceCounts, g_ffx_fsr2_depth_clip_pass_5ac420717bf1b90c9d119e6b959d751a_TextureSRVResourceSets, 2, g_ffx_fsr2_depth_clip_pass_5ac420717bf1b90c9d119e6b959d751a_TextureUAVResourceNames, g_ffx_fsr2_depth_clip_pass_5ac420717bf1b90c9d119e6b959d751a_TextureUAVResourceBindings, g_ffx_fsr2_depth_clip_pass_5ac420717bf1b90c9d119e6b959d751a_TextureUAVResourceCounts, g_ffx_fsr2_depth_clip_pass_5ac420717bf1b90c9d119e6b959d751a_TextureUAVResourceSets, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, g_ffx_fsr2_depth_clip_pass_5ac420717bf1b90c9d119e6b959d751a_SamplerResourceNames, g_ffx_fsr2_depth_clip_pass_5ac420717bf1b90c9d119e6b959d751a_SamplerResourceBindings, g_ffx_fsr2_depth_clip_pass_5ac420717bf1b90c9d119e6b959d751a_SamplerResourceCounts, g_ffx_fsr2_depth_clip_pass_5ac420717bf1b90c9d119e6b959d751a_SamplerResourceSets, 0, 0, 0, 0, 0, },
    { g_ffx_fsr2_depth_clip_pass_adaf8f0e7b2d6456053eac86ff26e3f8_size, g_ffx_fsr2_depth_clip_pass_adaf8f0e7b2d6456053eac86ff26e3f8_data, 1, g_ffx_fsr2_depth_clip_pass_adaf8f0e7b2d6456053eac86ff26e3f8_CBVResourceNames, g_ffx_fsr2_depth_clip_pass_adaf8f0e7b2d6456053eac86ff26e3f8_CBVResourceBindings, g_ffx_fsr2_depth_clip_pass_adaf8f0e7b2d6456053eac86ff26e3f8_CBVResourceCounts, g_ffx_fsr2_depth_clip_pass_adaf8f0e7b2d6456053eac86ff26e3f8_CBVResourceSets, 9, g_ffx_fsr2_depth_clip_pass_adaf8f0e7b2d6456053eac86ff26e3f8_TextureSRVResourceNames, g_ffx_fsr2_depth_clip_pass_adaf8f0e7b2d6456053eac86ff26e3f8_TextureSRVResourceBindings, g_ffx_fsr2_depth_clip_pass_adaf8f0e7b2d6456053eac86ff26e3f8_TextureSRVResourceCounts, g_ffx_fsr2_depth_clip_pass_adaf8f0e7b2d6456053eac86ff26e3f8_TextureSRVResourceSets, 2, g_ffx_fsr2_depth_clip_pass_adaf8f0e7b2d6456053eac86ff26e3f8_TextureUAVResourceNames, g_ffx_fsr2_depth_clip_pass_adaf8f0e7b2d6456053eac86ff26e3f8_TextureUAVResourceBindings, g_ffx_fsr2_depth_clip_pass_adaf8f0e7b2d6456053eac86ff26e3f8_TextureUAVResourceCounts, g_ffx_fsr2_depth_clip_pass_adaf8f0e7b2d6456053eac86ff26e3f8_TextureUAVResourceSets, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, g_ffx_fsr2_depth_clip_pass_adaf8f0e7b2d6456053eac86ff26e3f8_SamplerResourceNames, g_ffx_fsr2_depth_clip_pass_adaf8f0e7b2d6456053eac86ff26e3f8_SamplerResourceBindings, g_ffx_fsr2_depth_clip_pass_adaf8f0e7b2d6456053eac86ff26e3f8_SamplerResourceCounts, g_ffx_fsr2_depth_clip_pass_adaf8f0e7b2d6456053eac86ff26e3f8_SamplerResourceSets, 0, 0, 0, 0, 0, },
    { g_ffx_fsr2_depth_clip_pass_b6baac80d7cd8ba5f1a20e78bd2e7e3b_size, g_ffx_fsr2_depth_clip_pass_b6baac80d7cd8ba5f1a20e78bd2e7e3b_data, 1, g_ffx_fsr2_depth_clip_pass_b6baac80d7cd8ba5f1a20e78bd2e7e3b_CBVResourceNames, g_ffx_fsr2_depth_clip_pass_b6baac80d7cd8ba5f1a20e78bd2e7e3b_CBVResourceBindings, g_ffx_fsr2_depth_clip_pass_b6baac80d7cd8ba5f1a20e78bd2e7e3b_CBVResourceCounts, g_ffx_fsr2_depth_clip_pass_b6baac80d7cd8ba5f1a20e78bd2e7e3b_CBVResourceSets, 9, g_ffx_fsr2_depth_clip_pass_b6baac80d7cd8ba5f1a20e78bd2e7e3b_TextureSRVResourceNames, g_ffx_fsr2_depth_clip_pass_b6baac80d7cd8ba5f1a20e78bd2e7e3b_TextureSRVResourceBindings, g_ffx_fsr2_depth_clip_pass_b6baac80d7cd8ba5f1a20e78bd2e7e3b_TextureSRVResourceCounts, g_ffx_fsr2_depth_clip_pass_b6baac80d7cd8ba5f1a20e78bd2e7e3b_TextureSRVResourceSets, 2, g_ffx_fsr2_depth_clip_pass_b6baac80d7cd8ba5f1a20e78bd2e7e3b_TextureUAVResourceNames, g_ffx_fsr2_depth_clip_pass_b6baac80d7cd8ba5f1a20e78bd2e7e3b_TextureUAVResourceBindings, g_ffx_fsr2_depth_clip_pass_b6baac80d7cd8ba5f1a20e78bd2e7e3b_TextureUAVResourceCounts, g_ffx_fsr2_depth_clip_pass_b6baac80d7cd8ba5f1a20e78bd2e7e3b_TextureUAVResourceSets, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, g_ffx_fsr2_depth_clip_pass_b6baac80d7cd8ba5f1a20e78bd2e7e3b_SamplerResourceNames, g_ffx_fsr2_depth_clip_pass_b6baac80d7cd8ba5f1a20e78bd2e7e3b_SamplerResourceBindings, g_ffx_fsr2_depth_clip_pass_b6baac80d7cd8ba5f1a20e78bd2e7e3b_SamplerResourceCounts, g_ffx_fsr2_depth_clip_pass_b6baac80d7cd8ba5f1a20e78bd2e7e3b_SamplerResourceSets, 0, 0, 0, 0, 0, },
    { g_ffx_fsr2_depth_clip_pass_c4b4a1b9ebe6e75fc4a5817dad83144a_size, g_ffx_fsr2_depth_clip_pass_c4b4a1b9ebe6e75fc4a5817dad83144a_data, 1, g_ffx_fsr2_depth_clip_pass_c4b4a1b9ebe6e75fc4a5817dad83144a_CBVResourceNames, g_ffx_fsr2_depth_clip_pass_c4b4a1b9ebe6e75fc4a5817dad83144a_CBVResourceBindings, g_ffx_fsr2_depth_clip_pass_c4b4a1b9ebe6e75fc4a5817dad83144a_CBVResourceCounts, g_ffx_fsr2_depth_clip_pass_c4b4a1b9ebe6e75fc4a5817dad83144a_CBVResourceSets, 9, g_ffx_fsr2_depth_clip_pass_c4b4a1b9ebe6e75fc4a5817dad83144a_TextureSRVResourceNames, g_ffx_fsr2_depth_clip_pass_c4b4a1b9ebe6e75fc4a5817dad83144a_TextureSRVResourceBindings, g_ffx_fsr2_depth_clip_pass_c4b4a1b9ebe6e75fc4a5817dad83144a_TextureSRVResourceCounts, g_ffx_fsr2_depth_clip_pass_c4b4a1b9ebe6e75fc4a5817dad83144a_TextureSRVResourceSets, 2, g_ffx_fsr2_depth_clip_pass_c4b4a1b9ebe6e75fc4a5817dad83144a_TextureUAVResourceNames, g_ffx_fsr2_depth_clip_pass_c4b4a1b9ebe6e75fc4a5817dad83144a_TextureUAVResourceBindings, g_ffx_fsr2_depth_clip_pass_c4b4a1b9ebe6e75fc4a5817dad83144a_TextureUAVResourceCounts, g_ffx_fsr2_depth_clip_pass_c4b4a1b9ebe6e75fc4a5817dad83144a_TextureUAVResourceSets, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, g_ffx_fsr2_depth_clip_pass_c4b4a1b9ebe6e75fc4a5817dad83144a_SamplerResourceNames, g_ffx_fsr2_depth_clip_pass_c4b4a1b9ebe6e75fc4a5817dad83144a_SamplerResourceBindings, g_ffx_fsr2_depth_clip_pass_c4b4a1b9ebe6e75fc4a5817dad83144a_SamplerResourceCounts, g_ffx_fsr2_depth_clip_pass_c4b4a1b9ebe6e75fc4a5817dad83144a_SamplerResourceSets, 0, 0, 0, 0, 0, },
};

